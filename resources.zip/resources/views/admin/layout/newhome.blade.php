<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap Demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <style>




body{
    background-image: url("{{ asset('images/download.png') }}");
    background-repeat: no-repeat;
    background-size: cover;
    background-position: center;
}






        a {
            display: inline-block;

            margin: 5px;
            /* Adjust margin as needed */
            position: relative;
            padding: 6px 15px;
            box-shadow: 0 0 10px 5px rgba(0, 0, 0, 0.4);
            color: #999;
            text-decoration: none;
            text-transform: uppercase;
            letter-spacing: 4px;
            font: 700 30px consolas;
            overflow: hidden;
        }

        a span:nth-child(1) {
            position: absolute;
            top: 0;
            right: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(to right, #171618, #3bff3b);
            animation: animate1 2s linear infinite;
        }

        @keyframes animate1 {
            0% {
                transform: translateX(-100%);
            }

            100% {
                transform: translateX(100%);
            }
        }

        a span:nth-child(2) {
            position: absolute;
            top: 0;
            right: 0;
            height: 100%;
            width: 3px;
            background: linear-gradient(to bottom, #171618, #3bff3b);
            animation: animate2 2s linear infinite;
            animation-delay: 1s;
        }

        @keyframes animate2 {
            0% {
                transform: translateY(-100%);
            }

            100% {
                transform: translateY(100%);
            }
        }

        a span:nth-child(3) {
            position: absolute;
            bottom: 0;
            right: 0;
            width: 100%;
            height: 3px;
            background: linear-gradient(to left, #171618, #3bff3b);
            animation: animate3 2s linear infinite;
        }

        @keyframes animate3 {
            0% {
                transform: translateX(100%);
            }

            100% {
                transform: translateX(-100%);
            }
        }

        a span:nth-child(4) {
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 3px;
            background: linear-gradient(to top, #171618, #3bff3b);
            animation: animate4 2s linear infinite;
            animation-delay: 1s;
        }

        @keyframes animate4 {
            0% {
                transform: translateY(100%);
            }

            100% {
                transform: translateY(-100%);
            }
        }

        iframe {
            width: 100%;
            height: 491px;
        }


td{
    border: 2px solid darkblue
}
body {
            overflow: hidden; /* Hide scroll bars caused by the video */
            margin: 0; /* Remove default margin */
        }

        #video-background {
            position: fixed;
            top: 0;
            left: 0;
            min-width: 100%;
            min-height: 100%;
            width: auto;
            height: auto;
            z-index: -1; /* Place the video behind other elements */
        }
        
    </style>
</head>

<body>
    <video id="video-background" autoplay muted loop>
        <!-- Update the source with the correct path to your video -->
        <source src="/stock-footage-zodiac-spiral-and-signs-of-the-zodiac-in-space-astrology-horoscopes-and-prediction-of-the-future.webm" type="video/webm">
        <!-- Add more source elements for different video formats if needed -->
        Your browser does not support the video tag.
    </video>

    <div class="container">


        <div class="shadow-lg p-4 my-5">

            <div class="d-flex justify-content-between">
                <a href="https://example.com" target="_blank">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <p id="currentDate">6/12/2023</p>
                </a>

                <!-- Animated Button 3 -->
                <a href="https://example.org" target="_blank">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>

                    <p id="currentTime"></p>
                </a>
                <a href="https://example.org" target="_blank">
                    <span></span>
                    <span></span>
                    <span></span>
                    <span></span>
                    <p id="currentDate">6/12/2023</p>
                </a>
            </div>



            <div class="video-container col-md-12">
                <iframe src="https://g2.ipcamlive.com/player/player.php?alias=5e5a05863bb0b" allowfullscreen></iframe>
            </div>


            <div class="table-responsive">
                <table class="table text-center table-bordered border-dark">
                    {{-- <h3 class="text-center">Today Lucky Draw</h3> --}}
                    <thead class="table-dark">
                        <tr>
                            @for ($i = 10; $i <= 61; $i++) <th>Column {{ $i }}</th>
                                @endfor
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            @for ($i = 10; $i <= 61; $i++) <td> {{ $i }}</td>
                                @endfor
                        </tr>
                        <tr>
                            @for ($i = 10; $i <= 61; $i++) <td> {{ $i }}</td>
                                @endfor
                        </tr>
                    </tbody>
                </table>
            </div>

        </div>

    </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous">
    </script>

    <script>
        function updateDateTime() {
        var currentTime = new Date();
        var options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        var currentDate = currentTime.toLocaleDateString('en-US', options);

        document.getElementById('currentTime').innerText = ' ' + currentTime.toLocaleTimeString();
        // document.getElementById('currentDate').innerText = 'Current Date: ' + currentDate;
    }

    setInterval(updateDateTime, 1000);
    updateDateTime();
    </script>
</body>

</html>